SEAN AN - EDUKASI KESELAMATAN PELAYARAN

Isi folder:
- index.html : halaman website lengkap.

Cara menjalankan:
1. Buka index.html di browser.
2. Koneksi internet diperlukan untuk gambar eksternal.
3. Tombol DISTRESS hanya membuka simulasi edukasi dan tidak mengirim sinyal radio.

Untuk GitHub Pages, unggah index.html ke repositori lalu aktifkan Pages dari branch yang digunakan.
