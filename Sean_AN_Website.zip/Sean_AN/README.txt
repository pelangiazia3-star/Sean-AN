SEAN AN - WEBSITE EDUKASI KESELAMATAN PELAYARAN

ZIP ini berisi index.html dan petunjuk. Untuk menampilkan foto, salin tiga foto Anda ke folder yang sama dengan index.html dengan nama persis:
- IMG20260924093513.jpg
- IMG20260924093521.jpg
- IMG-20261007-WA0001.jpg

Buka index.html di browser atau fitur Preview HTML. Untuk GitHub Pages, unggah index.html dan ketiga foto ke repositori yang sama.
Catatan: panah pada gambar galeri ketiga adalah penanda CSS; posisi mungkin perlu disesuaikan dengan foto asli.
